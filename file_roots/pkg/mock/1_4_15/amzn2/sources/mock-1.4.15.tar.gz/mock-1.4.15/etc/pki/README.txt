Any file named
  RPM-GPG-KEY-*
is copied into chroot to directory /etc/pki/mock/.

You can use it for your personal GPG keys.

All distribution GPG keys are in package distribution-gpg-keys. 
