"""All of the mock utility classes."""
