* The original project was created inside of the huge `Chandler project`_
  where it was mostly work of Ng Pheng Siong [#]_ .

* Then for a log time it was maintained and extended to the large part
  by Heikki Toivonen.
  
With 247 and 415 commits, respectively, these two first maintainers
provided by far the biggest amount of work on the project.  Thank you.

* An attempt to restart the project was made by Martin Paljak. Although
  his effort was most mostly discarded in the end, all his suggested
  changes were reviewed and some of them incorporated in some other
  form. Just two commits of his remaining in the tree hugely
  underestimate an effort he made to keep this project alive. Thank you
  very much for your work.

* Plenty of work on keeping this project alive was made by the
  maintainer of the package inside of RHEL, Martin Trmač. He also helped
  a lot by advice with this last effort to revive the project, and his
  pestering me to do proper small commits rather than freaking dumps of
  my current thoughts helped to make changes to be made a little bit
  better (and revieweable).

* This last hyena-like effort to revive a dead carcas has been started
  by Matěj Cepl.

* I got a lot of help especially with reviewing patches from Hubert
  Kario.

* Craig Rodrigues didn't loose the hope that M2Crypto could be ported to
  be py3k-compatible, which lead to the renewed effort to do so. He also
  helped with plenty of patches in this effort.

* Casey Deccio helped a lot with fixing EC module.

* Remaining contributors could be find in the output of ``git shortlog
  -s`` command. Thank you to all.

.. _`Chandler project`:
    https://en.wikipedia.org/wiki/Chandler_%28software%29

.. [#] His and everybody else emails can be found in the git log,
    I won't make spammers even more happy to collect them here.
