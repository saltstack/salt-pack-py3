from pyroute2.netlink import nla


class vti6(nla):
    nla_map = (('IFLA_VTI_UNSPEC', 'none'),
               ('IFLA_VTI_LINK', 'uint32'),
               ('IFLA_VTI_IKEY', 'be32'),
               ('IFLA_VTI_OKEY', 'be32'),
               ('IFLA_VTI_LOCAL', 'ip6addr'),
               ('IFLA_VTI_REMOTE', 'ip6addr'),
               ('IFLA_VTI_FWMARK', 'uint32'))
