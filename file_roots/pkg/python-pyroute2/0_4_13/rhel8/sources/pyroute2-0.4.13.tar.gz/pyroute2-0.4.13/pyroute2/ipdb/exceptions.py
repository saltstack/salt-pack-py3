

class DeprecationException(Exception):
    pass


class CommitException(Exception):
    pass


class CreateException(Exception):
    pass


class PartialCommitException(Exception):
    pass
