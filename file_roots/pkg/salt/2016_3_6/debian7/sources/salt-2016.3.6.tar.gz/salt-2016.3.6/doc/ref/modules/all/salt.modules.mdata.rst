==========================
salt.modules.mdata
==========================

.. automodule:: salt.modules.mdata
    :members:
