=====================
salt.beacons.journald
=====================

.. automodule:: salt.beacons.journald
    :members: