=====================
salt.modules.boto_rds
=====================

.. automodule:: salt.modules.boto_rds
    :members: