salt.modules.boto_iot module
============================

.. automodule:: salt.modules.boto_iot
    :members:
