==========================
salt.modules.smartos_vmadm
==========================

.. automodule:: salt.modules.smartos_vmadm
    :members: