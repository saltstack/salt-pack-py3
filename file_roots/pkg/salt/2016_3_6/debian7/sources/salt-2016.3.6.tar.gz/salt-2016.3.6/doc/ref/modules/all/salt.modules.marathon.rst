salt.modules.marathon module
============================

.. automodule:: salt.modules.marathon
    :members:
