=============================
salt.modules.openstack_config
=============================

.. automodule:: salt.modules.openstack_config
    :members: