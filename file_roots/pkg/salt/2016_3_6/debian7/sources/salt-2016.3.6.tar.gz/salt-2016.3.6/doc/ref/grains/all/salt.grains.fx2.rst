===============
salt.grains.fx2
===============

.. automodule:: salt.grains.fx2
    :members:
