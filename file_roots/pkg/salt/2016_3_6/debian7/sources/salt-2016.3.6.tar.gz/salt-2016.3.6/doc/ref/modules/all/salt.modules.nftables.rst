=====================
salt.modules.nftables
=====================

.. automodule:: salt.modules.nftables
    :members: