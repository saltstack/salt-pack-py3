.. _all-salt.grains:

==============
grains modules
==============

.. currentmodule:: salt.grains

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    chronos
    core
    disks
    esxi
    extra
    fx2
    junos
    marathon
    mdadm
    opts
    philips_hue
    rest_sample
