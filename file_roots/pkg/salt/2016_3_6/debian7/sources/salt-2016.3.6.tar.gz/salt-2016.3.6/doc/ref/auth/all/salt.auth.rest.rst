salt.auth.rest module
=====================

.. automodule:: salt.auth.rest
    :members:
