# -*- coding: utf-8 -*-


def myfunction():
    grains = {}
    grains['a_custom'] = {'k2': 'v2'}
    return grains
