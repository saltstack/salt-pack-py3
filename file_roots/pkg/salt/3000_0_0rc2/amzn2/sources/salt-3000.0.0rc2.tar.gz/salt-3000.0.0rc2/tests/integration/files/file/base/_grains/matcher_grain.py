# -*- coding: utf-8 -*-


def myfunction():
    grains = {}
    grains['match'] = 'maker'
    return grains
