test -n "$1" || exit -127

exit $1
