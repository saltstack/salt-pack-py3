=======================
salt.modules.freebsdpkg
=======================

.. automodule:: salt.modules.freebsdpkg
    :members:
    :exclude-members: available_version, delete, purge