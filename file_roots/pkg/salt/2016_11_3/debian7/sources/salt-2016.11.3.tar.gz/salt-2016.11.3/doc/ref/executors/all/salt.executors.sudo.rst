salt.executors.sudo module
==========================

.. automodule:: salt.executors.sudo
    :members:

