====================
salt.modules.mongodb
====================

.. automodule:: salt.modules.mongodb
    :members: