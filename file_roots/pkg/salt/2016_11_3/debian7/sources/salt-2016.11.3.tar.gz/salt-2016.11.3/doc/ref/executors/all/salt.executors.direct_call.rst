salt.executors.direct_call module
=================================

.. automodule:: salt.executors.direct_call
    :members:

