salt.beacons.bonjour_announce module
====================================

.. automodule:: salt.beacons.bonjour_announce
    :members:
    :undoc-members:
