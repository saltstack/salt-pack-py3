===============================
salt.cloud.clouds.aliyun
===============================

.. automodule:: salt.cloud.clouds.aliyun
    :members: