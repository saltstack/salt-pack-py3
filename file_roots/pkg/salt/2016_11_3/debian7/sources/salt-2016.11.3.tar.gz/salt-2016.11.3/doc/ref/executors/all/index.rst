.. _all-salt_executors:

=================
executors modules
=================

.. currentmodule:: salt.executors

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    direct_call
    splay
    sudo
