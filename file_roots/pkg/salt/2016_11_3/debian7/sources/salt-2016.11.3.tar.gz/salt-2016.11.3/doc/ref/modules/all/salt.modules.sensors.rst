====================
salt.modules.sensors
====================

.. automodule:: salt.modules.sensors
    :members: