salt.beacons.glxinfo module
===========================

.. automodule:: salt.beacons.glxinfo
    :members:
