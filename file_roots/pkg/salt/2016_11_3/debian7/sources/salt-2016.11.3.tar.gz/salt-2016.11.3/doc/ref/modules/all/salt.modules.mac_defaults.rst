salt.modules.mac_defaults module
================================

.. automodule:: salt.modules.mac_defaults
    :members:
