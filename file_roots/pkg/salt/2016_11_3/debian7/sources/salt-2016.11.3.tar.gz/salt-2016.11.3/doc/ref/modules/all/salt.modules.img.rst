================
salt.modules.img
================

.. automodule:: salt.modules.img
    :members:
    :exclude-members: mnt_image