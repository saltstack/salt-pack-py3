==================
salt.modules.bluez
==================

.. automodule:: salt.modules.bluez
    :members: