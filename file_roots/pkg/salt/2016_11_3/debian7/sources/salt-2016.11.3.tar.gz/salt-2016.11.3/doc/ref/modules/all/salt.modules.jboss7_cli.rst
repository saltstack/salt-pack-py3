=======================
salt.modules.jboss7_cli
=======================

.. automodule:: salt.modules.jboss7_cli
    :members: