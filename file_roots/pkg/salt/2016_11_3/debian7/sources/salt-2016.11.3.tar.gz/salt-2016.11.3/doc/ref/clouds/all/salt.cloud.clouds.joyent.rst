========================
salt.cloud.clouds.joyent
========================

.. automodule:: salt.cloud.clouds.joyent
    :members: