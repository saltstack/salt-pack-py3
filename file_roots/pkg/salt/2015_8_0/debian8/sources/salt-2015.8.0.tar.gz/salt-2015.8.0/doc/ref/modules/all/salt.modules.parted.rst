===================
salt.modules.parted
===================

.. automodule:: salt.modules.parted
    :members: