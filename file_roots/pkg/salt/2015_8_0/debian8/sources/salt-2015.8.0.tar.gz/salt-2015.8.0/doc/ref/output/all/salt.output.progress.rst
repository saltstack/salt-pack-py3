====================
salt.output.progress
====================

.. automodule:: salt.output.progress
    :members:
