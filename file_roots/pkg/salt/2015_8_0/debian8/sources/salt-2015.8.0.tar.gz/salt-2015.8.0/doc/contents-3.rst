======================
Salt Table of Contents
======================

.. toctree::
    :maxdepth: 3
    :glob:

    topics/master_tops/index
    topics/ssh/*
    topics/best_practices
    topics/troubleshooting/index
    topics/development/index
    topics/releases/index
    topics/projects/index
    security/index
    faq
    glossary