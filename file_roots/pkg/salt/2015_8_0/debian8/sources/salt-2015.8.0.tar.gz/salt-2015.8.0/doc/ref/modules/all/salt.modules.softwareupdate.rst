===========================
salt.modules.softwareupdate
===========================

.. automodule:: salt.modules.softwareupdate
    :members: