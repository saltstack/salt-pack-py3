================
salt.modules.dig
================

.. automodule:: salt.modules.dig
    :members:
    :exclude-members: a, aaaa, ns, spf, mx