.. _all-salt.clouds:

===============================
Full list of Salt Cloud modules
===============================

.. currentmodule:: salt.cloud.clouds

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    aliyun
    botocore_aws
    cloudstack
    digital_ocean
    digital_ocean_v2
    ec2
    gce
    gogrid
    joyent
    libcloud_aws
    linode
    lxc
    msazure
    nova
    opennebula
    openstack
    parallels
    proxmox
    pyrax
    rackspace
    saltify
    softlayer
    softlayer_hw
    vmware
    vsphere
