.. _all-netapi-modules:

===========================
Full list of netapi modules
===========================

.. toctree::
    :maxdepth: 2

    salt.netapi.rest_cherrypy
    salt.netapi.rest_tornado
    salt.netapi.rest_wsgi