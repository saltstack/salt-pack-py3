=====================
salt.modules.win_dacl
=====================

.. automodule:: salt.modules.win_dacl
    :members: