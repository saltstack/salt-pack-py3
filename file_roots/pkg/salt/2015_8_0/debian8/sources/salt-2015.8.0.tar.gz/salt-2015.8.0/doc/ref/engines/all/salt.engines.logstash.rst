=====================
salt.engines.logstash
=====================

.. automodule:: salt.engines.logstash
    :members: