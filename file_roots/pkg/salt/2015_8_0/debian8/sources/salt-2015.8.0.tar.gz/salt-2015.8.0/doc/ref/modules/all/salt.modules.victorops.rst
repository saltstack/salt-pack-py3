======================
salt.modules.victorops
======================

.. automodule:: salt.modules.victorops
    :members:
