=================
salt.modules.brew
=================

.. automodule:: salt.modules.brew
    :members:
    :exclude-members: available_version