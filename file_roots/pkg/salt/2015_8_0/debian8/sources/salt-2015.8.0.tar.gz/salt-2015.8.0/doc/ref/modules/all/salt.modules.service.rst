====================
salt.modules.service
====================

.. automodule:: salt.modules.service
    :members: