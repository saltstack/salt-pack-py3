===============================
salt.output.newline_values_only
===============================

.. automodule:: salt.output.newline_values_only
    :members: