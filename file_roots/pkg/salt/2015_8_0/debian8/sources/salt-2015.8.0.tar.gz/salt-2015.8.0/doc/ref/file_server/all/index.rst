.. _all-salt.fileserver:

=======================================
Full list of builtin fileserver modules
=======================================

.. currentmodule:: salt.fileserver

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    azurefs
    gitfs
    hgfs
    minionfs
    roots
    s3fs
    svnfs
