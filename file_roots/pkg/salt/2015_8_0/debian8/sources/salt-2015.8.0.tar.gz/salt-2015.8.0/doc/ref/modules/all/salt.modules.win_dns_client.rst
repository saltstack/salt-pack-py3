===========================
salt.modules.win_dns_client
===========================

.. automodule:: salt.modules.win_dns_client
    :members: