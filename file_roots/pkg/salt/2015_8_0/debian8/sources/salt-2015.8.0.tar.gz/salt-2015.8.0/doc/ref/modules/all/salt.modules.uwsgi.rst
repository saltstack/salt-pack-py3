==================
salt.modules.uwsgi
==================

.. automodule:: salt.modules.uwsgi
    :members: