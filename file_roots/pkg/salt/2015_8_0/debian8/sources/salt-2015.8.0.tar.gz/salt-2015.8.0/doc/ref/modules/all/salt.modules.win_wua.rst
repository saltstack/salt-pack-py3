====================
salt.modules.win_wua
====================

.. automodule:: salt.modules.win_wua
    :members:
