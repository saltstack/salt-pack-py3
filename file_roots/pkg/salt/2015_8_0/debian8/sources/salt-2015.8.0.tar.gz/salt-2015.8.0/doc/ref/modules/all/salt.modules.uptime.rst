===================
salt.modules.uptime
===================

.. automodule:: salt.modules.uptime
    :members:
