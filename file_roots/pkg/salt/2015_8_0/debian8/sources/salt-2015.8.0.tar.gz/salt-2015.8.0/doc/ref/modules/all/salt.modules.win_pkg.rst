====================
salt.modules.win_pkg
====================

.. automodule:: salt.modules.win_pkg
    :members:
    :exclude-members: available_version