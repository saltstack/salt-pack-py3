==================
salt.modules.ifttt
==================

.. automodule:: salt.modules.ifttt
    :members:
