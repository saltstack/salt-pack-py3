========================
salt.modules.rest_sample
========================

.. automodule:: salt.modules.rest_sample
    :members: