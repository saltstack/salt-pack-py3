===================
salt.modules.shadow
===================

.. automodule:: salt.modules.shadow
    :members: