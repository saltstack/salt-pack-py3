=========================
salt.modules.win_powercfg
=========================

.. automodule:: salt.modules.win_powercfg
    :members: