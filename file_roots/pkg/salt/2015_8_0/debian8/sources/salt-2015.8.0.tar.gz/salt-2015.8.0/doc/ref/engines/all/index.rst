.. _all-salt.engines:

===================================
Full list of builtin engine modules
===================================

.. currentmodule:: salt.engines

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    logstash
    sqs_events
    test
