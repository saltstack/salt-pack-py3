#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

__docformat__ = 'restructuredtext en'


def hello(name):
    return "hello " + name

# vim:set et sts=4 ts=4 tw=80:
