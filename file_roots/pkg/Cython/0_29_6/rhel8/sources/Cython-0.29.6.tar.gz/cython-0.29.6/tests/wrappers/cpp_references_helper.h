
int ref_var_value = 10;
int& ref_var = ref_var_value;

int& ref_func(int& x) { return x; }
