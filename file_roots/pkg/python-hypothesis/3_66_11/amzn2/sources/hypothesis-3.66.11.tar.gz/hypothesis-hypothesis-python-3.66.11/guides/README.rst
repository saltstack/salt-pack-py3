=================================
Guides for Hypothesis Development
=================================

This is a general collection of useful documentation for people
working on Hypothesis.

It is separate from the main documentation because it is not much
use if you are merely *using* Hypothesis. It's purely for working
on it.

Most of these are currently written with the Python version of
Hypothesis in mind, but will evolve over time to be more multilingual.
