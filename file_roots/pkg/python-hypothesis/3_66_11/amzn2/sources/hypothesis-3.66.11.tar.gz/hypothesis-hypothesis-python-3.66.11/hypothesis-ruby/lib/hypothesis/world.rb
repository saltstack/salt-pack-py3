# frozen_string_literal: true

module Hypothesis
  module World
    class << self
        attr_accessor :current_engine
    end
  end
end
