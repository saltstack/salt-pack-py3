extern crate core;
extern crate rand;

pub mod data;
pub mod distributions;
pub mod engine;
pub mod intminimize;
