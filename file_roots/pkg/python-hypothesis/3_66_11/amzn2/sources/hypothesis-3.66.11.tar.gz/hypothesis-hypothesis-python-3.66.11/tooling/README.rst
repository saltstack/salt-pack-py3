========================
Hypothesis Build Tooling
========================

This is a piece of software for managing Hypothesis's build tasks, releases,
etc. It's very Hypothesis specific, though it may become less so in the future.
