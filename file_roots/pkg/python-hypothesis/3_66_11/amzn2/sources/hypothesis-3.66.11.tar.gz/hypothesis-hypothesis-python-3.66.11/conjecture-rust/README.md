# Conjecture for Rust

Conjecture is the core engine for Hypothesis. This is a Rust implementation of it,
designed to be shared between multiple library implementations. Currently only
Hypothesis for Ruby uses it.

It is unlikely that you want to use this library directly if you are not working
on a Hypothesis implementation, and it exists primarily to share code between them.
