Thanks for contributing to python-atomicwrites! This document is a
work-in-progress. Below are a few notes that are useful for writing patches.

Running the tests
=================

::

    pip install tox
    tox -e py-test
    tox -e py-stylecheck
